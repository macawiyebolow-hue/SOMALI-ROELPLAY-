package com.somalirp.launcher

object Config {
    const val SERVER_NAME = "Somali Roleplay"
    const val SERVER_IP = "51.254.178.238"
    const val SERVER_PORT = 7777

    // TODO: put the direct download link of your game files ZIP here
    const val FILES_URL = "PUT_YOUR_FILES_ZIP_LINK_HERE"

    // TODO: package name of the SA-MP mobile client that Play should open
    const val CLIENT_PACKAGE = "com.samp.mobile"
}
