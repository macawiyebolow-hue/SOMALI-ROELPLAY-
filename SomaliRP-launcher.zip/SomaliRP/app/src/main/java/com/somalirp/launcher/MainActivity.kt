package com.somalirp.launcher

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {
    private var player: MediaPlayer? = null
    private lateinit var btn: Button
    private lateinit var bar: ProgressBar
    private lateinit var status: TextView
    private val marker by lazy { File(getExternalFilesDir(null), "installed.flag") }
    private val gameDir by lazy { File(getExternalFilesDir(null), "files").apply { mkdirs() } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        btn = findViewById(R.id.btn); bar = findViewById(R.id.bar); status = findViewById(R.id.status)
        player = MediaPlayer.create(this, R.raw.music)?.apply { isLooping = true; start() }
        refresh()
        btn.setOnClickListener { if (marker.exists()) play() else update() }
    }

    private fun refresh() {
        btn.text = getString(if (marker.exists()) R.string.play else R.string.update)
        status.text = getString(if (marker.exists()) R.string.ready else R.string.need_update)
    }

    private fun update() {
        btn.isEnabled = false
        Thread {
            try {
                val c = URL(Config.FILES_URL).openConnection() as HttpURLConnection
                val total = c.contentLengthLong
                var done = 0L
                ZipInputStream(c.inputStream.buffered()).use { z ->
                    var e = z.nextEntry
                    val buf = ByteArray(8192)
                    while (e != null) {
                        val out = File(gameDir, e.name)
                        if (!out.canonicalPath.startsWith(gameDir.canonicalPath)) throw Exception("bad zip")
                        if (e.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            out.outputStream().use { o ->
                                var n = z.read(buf)
                                while (n > 0) { o.write(buf, 0, n); done += n; post(done, total); n = z.read(buf) }
                            }
                        }
                        e = z.nextEntry
                    }
                }
                marker.writeText("ok")
                runOnUiThread { bar.progress = 100; btn.isEnabled = true; refresh() }
            } catch (ex: Exception) {
                runOnUiThread { btn.isEnabled = true; status.text = getString(R.string.error); Toast.makeText(this, ex.message, Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun post(done: Long, total: Long) = runOnUiThread {
        if (total > 0) bar.progress = (done * 100 / total).toInt()
        status.text = getString(R.string.downloading) + " " + (done / 1048576) + " MB"
    }

    private fun play() {
        val i = packageManager.getLaunchIntentForPackage(Config.CLIENT_PACKAGE)
        if (i == null) { Toast.makeText(this, R.string.no_client, Toast.LENGTH_LONG).show(); return }
        i.putExtra("ip", Config.SERVER_IP).putExtra("port", Config.SERVER_PORT)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    override fun onPause() { super.onPause(); player?.pause() }
    override fun onResume() { super.onResume(); player?.start() }
    override fun onDestroy() { super.onDestroy(); player?.release() }
}
